[app]

# ── Identificação ─────────────────────────────────────────────
title = SensorTracker
package.name = sensortracker
package.domain = com.seudominio

source.dir = .
source.include_exts = py,kv,png,jpg,ttf,atlas

version = 1.0.0

# ── Dependências ──────────────────────────────────────────────
requirements = python3,kivy==2.3.0,plyer

# ── Assets ────────────────────────────────────────────────────
presplash.filename = %(source.dir)s/assets/presplash.png
icon.filename      = %(source.dir)s/assets/icon.png

# ── Orientação e UI ───────────────────────────────────────────
orientation = portrait
fullscreen = 0

# ── Android ───────────────────────────────────────────────────
android.minapi    = 21
android.targetapi = 34
android.ndk       = 25b
android.sdk       = 34
android.archs     = arm64-v8a, armeabi-v7a

# Permissões necessárias
android.permissions =
    ACCESS_FINE_LOCATION,
    ACCESS_COARSE_LOCATION,
    ACCESS_BACKGROUND_LOCATION

# Habilita features de sensor
android.features =
    android.hardware.sensor.gyroscope,
    android.hardware.location.gps

# Compatível com gradle moderno
android.gradle_dependencies = com.google.android.gms:play-services-location:21.0.1

# Segurança: sem permissões desnecessárias
android.add_compile_options = -Xlint:all

[buildozer]

# Nível de log: 2 = verbose (use 1 em produção)
log_level = 2
warn_on_root = 1
