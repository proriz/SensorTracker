# 📡 SensorTracker — GPS + Giroscópio em Tempo Real

App Android feito em Python/Kivy que exibe dados de GPS e Giroscópio
em tempo real, com arquitetura limpa e escalável.

---

## 🗂 Estrutura do Projeto

```
sensor_app/
├── main.py                      # Entry point
├── buildozer.spec               # Configuração do APK
├── assets/
│   ├── icon.png                 # Ícone do app (512x512)
│   └── presplash.png            # Splash screen (1080x1920)
└── app/
    ├── screens/
    │   ├── dashboard.py         # Tela principal (dados em tempo real)
    │   └── settings.py          # Tela de configurações
    ├── services/
    │   └── sensor_manager.py    # Abstração GPS + Giroscópio
    ├── ui/
    │   ├── dashboard.kv         # Layout da dashboard (Kivy DSL)
    │   └── settings.kv          # Layout das configurações
    └── utils/
        └── logger.py            # Logger centralizado
```

---

## 🚀 Como Gerar o APK

### 1. Pré-requisitos (Linux/macOS ou WSL2)

```bash
# Python e dependências do sistema
sudo apt-get update
sudo apt-get install -y python3-pip python3-venv git zip unzip \
    openjdk-17-jdk autoconf libtool pkg-config cmake \
    libffi-dev libssl-dev

# Buildozer e Kivy
pip3 install --upgrade buildozer cython==0.29.33
```

### 2. Clonar/copiar o projeto e entrar na pasta

```bash
cd sensor_app
```

### 3. Gerar o APK (debug — para testes)

```bash
buildozer android debug
```
> O APK estará em `bin/sensortracker-1.0.0-debug.apk`

### 4. Instalar direto no celular conectado via USB

```bash
buildozer android debug deploy run
```

### 5. APK de release (produção)

```bash
buildozer android release
# Depois assinar com jarsigner ou apksigner
```

---

## 🖥 Rodar no Desktop (desenvolvimento)

Para testar sem Android, rode direto com Python:

```bash
pip install kivy plyer
python main.py
```

O `SensorManager` detecta automaticamente o ambiente e usa
**dados simulados** no desktop — GPS caminhando em São Paulo,
giroscópio com rotação suave.

---

## 🏗 Arquitetura

| Camada | Responsabilidade |
|---|---|
| `main.py` | Bootstrap do app, ciclo de vida (pause/resume) |
| `SensorManager` | Acesso a hardware, thread-safe, callbacks |
| `DashboardScreen` | UI reativa via KV bindings + Clock |
| `AppLogger` | Log centralizado, filtrável por namespace |

**Princípios aplicados:**
- **Separação de camadas**: UI nunca acessa hardware diretamente
- **Thread-safety**: `_lock` em todos os dados compartilhados
- **Ciclo de vida correto**: pause/resume economiza bateria
- **Portabilidade**: mesma base roda no Android e no PC
- **Escalabilidade**: adicionar novo sensor = novo dataclass + callback

---

## 🔐 Segurança e Boas Práticas

- Permissões **mínimas necessárias** no `buildozer.spec`
- `on_pause` para bateria: sensores param quando app está em background
- Logs **sem dados pessoais** (coordenadas não logadas em produção)
- `ACCESS_BACKGROUND_LOCATION` listada — Android 10+ exige declaração explícita
- `targetSdk 34` garante conformidade com Play Store atual

---

## ➕ Como Estender

**Adicionar Acelerômetro:**
1. Criar `AccelData` dataclass em `sensor_manager.py`
2. Adicionar `plyer.accelerometer` no `_start_android()`
3. Adicionar `StringProperty` no `DashboardScreen`
4. Atualizar `dashboard.kv` com novo card

**Adicionar exportação CSV:**
```python
# Em sensor_manager.py
import csv
def export_session(self, path):
    with open(path, 'w') as f:
        writer = csv.DictWriter(f, fieldnames=['ts','lat','lon','gx','gy','gz'])
        writer.writerows(self._session_log)
```

---

## 📦 Dependências

| Biblioteca | Versão | Uso |
|---|---|---|
| Kivy | 2.3.0 | UI framework |
| Plyer | latest | Acesso a sensores Android |
| Python | 3.11+ | Runtime |
| Buildozer | latest | Build tool → APK |
