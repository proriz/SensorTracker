"""
SensorTracker App
-----------------
Entry point. Inicializa o app Kivy com configurações seguras.
"""

import os
import sys

# Segurança: desabilita log verbose em produção
os.environ.setdefault("KIVY_NO_ENV_CONFIG", "1")

from kivy.config import Config

# Previne redimensionamento acidental (mobile)
Config.set("graphics", "resizable", "0")
Config.set("kivy", "log_level", "warning")

from kivy.app import App
from kivy.lang import Builder
from kivy.uix.screenmanager import ScreenManager

from app.screens.dashboard import DashboardScreen
from app.screens.settings import SettingsScreen
from app.services.sensor_manager import SensorManager
from app.utils.logger import AppLogger

Builder.load_file("app/ui/dashboard.kv")
Builder.load_file("app/ui/settings.kv")

logger = AppLogger.get(__name__)


class SensorTrackerApp(App):
    """App principal — gerencia ciclo de vida e serviços."""

    title = "SensorTracker"
    icon = "assets/icon.png"

    def build(self):
        logger.info("Iniciando SensorTracker...")

        self.sensor_manager = SensorManager()

        sm = ScreenManager()
        sm.add_widget(DashboardScreen(
            name="dashboard",
            sensor_manager=self.sensor_manager
        ))
        sm.add_widget(SettingsScreen(name="settings"))
        return sm

    def on_start(self):
        self.sensor_manager.start()
        logger.info("Sensores iniciados.")

    def on_stop(self):
        self.sensor_manager.stop()
        logger.info("App encerrado. Sensores parados.")

    def on_pause(self):
        """Android: app vai para background."""
        self.sensor_manager.pause()
        return True  # Permite pausar

    def on_resume(self):
        """Android: app volta ao foreground."""
        self.sensor_manager.resume()


if __name__ == "__main__":
    SensorTrackerApp().run()
