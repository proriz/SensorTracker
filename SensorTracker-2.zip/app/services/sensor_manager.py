"""
SensorManager
-------------
Camada de serviço que abstrai acesso ao GPS e Giroscópio.
Detecta automaticamente se está rodando no Android (plyer)
ou no desktop (simulação para desenvolvimento).
"""

import threading
from typing import Optional, Callable
from dataclasses import dataclass, field
from app.utils.logger import AppLogger

logger = AppLogger.get(__name__)


@dataclass
class GPSData:
    lat: float = 0.0
    lon: float = 0.0
    altitude: float = 0.0
    speed: float = 0.0
    accuracy: float = 0.0
    status: str = "aguardando..."


@dataclass
class GyroData:
    x: float = 0.0
    y: float = 0.0
    z: float = 0.0
    status: str = "aguardando..."


class SensorManager:
    """
    Gerencia ciclo de vida dos sensores.
    Thread-safe. Notifica observers via callbacks.
    """

    def __init__(self):
        self._lock = threading.Lock()
        self._running = False
        self._paused = False

        self.gps = GPSData()
        self.gyro = GyroData()

        self._on_gps_update: Optional[Callable] = None
        self._on_gyro_update: Optional[Callable] = None

        self._platform = self._detect_platform()
        self._gps_impl = None
        self._gyro_impl = None

    def _detect_platform(self) -> str:
        try:
            import android  # noqa
            return "android"
        except ImportError:
            return "desktop"

    # ── Callbacks ───────────────────────────────────────────

    def bind(self, on_gps=None, on_gyro=None):
        """Registra callbacks chamados quando dados atualizam."""
        if on_gps:
            self._on_gps_update = on_gps
        if on_gyro:
            self._on_gyro_update = on_gyro

    # ── Ciclo de vida ────────────────────────────────────────

    def start(self):
        with self._lock:
            if self._running:
                return
            self._running = True

        if self._platform == "android":
            self._start_android()
        else:
            self._start_desktop_simulation()

        logger.info(f"SensorManager iniciado [{self._platform}]")

    def pause(self):
        with self._lock:
            self._paused = True
        if self._platform == "android":
            self._stop_android_sensors()

    def resume(self):
        with self._lock:
            self._paused = False
        if self._platform == "android":
            self._start_android()

    def stop(self):
        with self._lock:
            self._running = False
        if self._platform == "android":
            self._stop_android_sensors()
        logger.info("SensorManager parado.")

    # ── Android (plyer) ──────────────────────────────────────

    def _start_android(self):
        try:
            from plyer import gps, gyroscope

            gps.configure(
                on_location=self._on_gps_raw,
                on_status=self._on_gps_status
            )
            gps.start(minTime=1000, minDistance=0)

            gyroscope.enable()
            self._gyro_impl = gyroscope
            self._start_gyro_polling()

        except Exception as e:
            logger.error(f"Erro ao iniciar sensores Android: {e}")
            self.gps.status = "erro"
            self.gyro.status = "erro"

    def _stop_android_sensors(self):
        try:
            from plyer import gps
            gps.stop()
        except Exception:
            pass
        try:
            from plyer import gyroscope
            gyroscope.disable()
        except Exception:
            pass

    def _on_gps_raw(self, **kwargs):
        with self._lock:
            self.gps.lat = round(kwargs.get("lat", 0.0), 6)
            self.gps.lon = round(kwargs.get("lon", 0.0), 6)
            self.gps.altitude = round(kwargs.get("altitude", 0.0), 1)
            self.gps.speed = round(kwargs.get("speed", 0.0), 2)
            self.gps.accuracy = round(kwargs.get("accuracy", 0.0), 1)
            self.gps.status = "ativo"
        if self._on_gps_update:
            self._on_gps_update(self.gps)

    def _on_gps_status(self, stype, status):
        with self._lock:
            self.gps.status = status
        logger.info(f"GPS status: {stype} / {status}")

    def _start_gyro_polling(self):
        """Poll giroscópio a cada 100ms em thread separada."""
        def poll():
            import time
            while self._running and not self._paused:
                try:
                    vals = self._gyro_impl.rotation
                    if vals:
                        with self._lock:
                            self.gyro.x = round(vals[0] or 0.0, 4)
                            self.gyro.y = round(vals[1] or 0.0, 4)
                            self.gyro.z = round(vals[2] or 0.0, 4)
                            self.gyro.status = "ativo"
                        if self._on_gyro_update:
                            self._on_gyro_update(self.gyro)
                except Exception as e:
                    logger.warning(f"Gyro poll erro: {e}")
                time.sleep(0.1)

        t = threading.Thread(target=poll, daemon=True)
        t.start()

    # ── Simulação Desktop ────────────────────────────────────

    def _start_desktop_simulation(self):
        """Gera dados simulados para desenvolvimento no PC."""
        import math, time, random

        self.gps.status = "simulado"
        self.gyro.status = "simulado"

        def simulate():
            t = 0.0
            base_lat = -23.5505  # São Paulo
            base_lon = -46.6333
            while self._running:
                if not self._paused:
                    t += 0.05
                    with self._lock:
                        # GPS: caminhada lenta simulada
                        self.gps.lat = round(base_lat + math.sin(t * 0.1) * 0.001, 6)
                        self.gps.lon = round(base_lon + math.cos(t * 0.1) * 0.001, 6)
                        self.gps.altitude = round(760 + math.sin(t) * 5, 1)
                        self.gps.speed = round(abs(math.sin(t * 0.5)) * 5, 2)
                        self.gps.accuracy = round(3.0 + random.uniform(0, 2), 1)

                        # Giroscópio: rotação suave
                        self.gyro.x = round(math.sin(t * 1.3) * 0.5, 4)
                        self.gyro.y = round(math.cos(t * 0.9) * 0.3, 4)
                        self.gyro.z = round(math.sin(t * 0.7) * 0.2, 4)

                    if self._on_gps_update:
                        self._on_gps_update(self.gps)
                    if self._on_gyro_update:
                        self._on_gyro_update(self.gyro)

                time.sleep(0.1)

        t = threading.Thread(target=simulate, daemon=True)
        t.start()
