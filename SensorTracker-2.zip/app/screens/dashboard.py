"""
DashboardScreen
---------------
Tela principal. Recebe atualizações do SensorManager via callbacks
e atualiza a UI na thread principal usando Clock.schedule_once.
"""

from kivy.uix.screenmanager import Screen
from kivy.clock import Clock
from kivy.properties import StringProperty, NumericProperty

from app.services.sensor_manager import SensorManager, GPSData, GyroData
from app.utils.logger import AppLogger

logger = AppLogger.get(__name__)


class DashboardScreen(Screen):
    # GPS properties (bind automático com .kv)
    gps_lat = StringProperty("--")
    gps_lon = StringProperty("--")
    gps_altitude = StringProperty("--")
    gps_speed = StringProperty("--")
    gps_accuracy = StringProperty("--")
    gps_status = StringProperty("aguardando...")

    # Gyro properties
    gyro_x = StringProperty("--")
    gyro_y = StringProperty("--")
    gyro_z = StringProperty("--")
    gyro_status = StringProperty("aguardando...")

    def __init__(self, sensor_manager: SensorManager, **kwargs):
        super().__init__(**kwargs)
        self._sensor_manager = sensor_manager
        self._sensor_manager.bind(
            on_gps=self._handle_gps,
            on_gyro=self._handle_gyro
        )

    # ── Handlers chamados de threads de sensor ───────────────

    def _handle_gps(self, data: GPSData):
        """Agenda atualização na thread principal (thread-safe)."""
        Clock.schedule_once(lambda dt: self._update_gps_ui(data))

    def _handle_gyro(self, data: GyroData):
        Clock.schedule_once(lambda dt: self._update_gyro_ui(data))

    # ── Atualização da UI ────────────────────────────────────

    def _update_gps_ui(self, data: GPSData):
        self.gps_lat = f"{data.lat:.6f}°"
        self.gps_lon = f"{data.lon:.6f}°"
        self.gps_altitude = f"{data.altitude:.1f} m"
        self.gps_speed = f"{data.speed:.2f} m/s"
        self.gps_accuracy = f"±{data.accuracy:.1f} m"
        self.gps_status = data.status

    def _update_gyro_ui(self, data: GyroData):
        self.gyro_x = f"{data.x:+.4f} rad/s"
        self.gyro_y = f"{data.y:+.4f} rad/s"
        self.gyro_z = f"{data.z:+.4f} rad/s"
        self.gyro_status = data.status

    def go_settings(self):
        self.manager.current = "settings"
