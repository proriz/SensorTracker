"""
SettingsScreen — Tela de configurações básicas.
Extensível para adicionar intervalo de atualização, unidades, etc.
"""

from kivy.uix.screenmanager import Screen


class SettingsScreen(Screen):

    def go_back(self):
        self.manager.current = "dashboard"
