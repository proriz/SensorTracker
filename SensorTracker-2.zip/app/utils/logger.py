"""
AppLogger — Logger centralizado e configurável.
Usa logging padrão do Python para compatibilidade total com Android.
"""

import logging
import sys


class AppLogger:
    _configured = False

    @classmethod
    def _configure(cls):
        if cls._configured:
            return
        handler = logging.StreamHandler(sys.stdout)
        handler.setFormatter(logging.Formatter(
            "[%(levelname)s] %(name)s — %(message)s"
        ))
        root = logging.getLogger("sensortracker")
        root.setLevel(logging.DEBUG)
        root.addHandler(handler)
        cls._configured = True

    @classmethod
    def get(cls, name: str) -> logging.Logger:
        cls._configure()
        # Prefixo garante que todos os loggers do app sejam filtráveis
        return logging.getLogger(f"sensortracker.{name}")
